const express=require('express');
const crypto=require('crypto');
require('dotenv').config();
const db=require('./db');
const {purchaseData}=require('./vtu');

const app=express();
app.use(express.json());
app.use(express.static(require('path').join(__dirname,'../frontend')));
const PORT=process.env.PORT||3000;

function admin(req,res,next){
  if(req.headers['x-admin-token']!==process.env.ADMIN_TOKEN) return res.status(401).json({error:'Unauthorized'});
  next();
}
function ref(){return 'DH_'+Date.now()+'_'+crypto.randomBytes(4).toString('hex');}

app.get('/api/plans',(req,res)=>{
  res.json(db.prepare('SELECT * FROM data_plans WHERE active=1 ORDER BY network,size_mb').all());
});

app.get('/api/health',(req,res)=>res.json({ok:true,mode:'test-first'}));

app.post('/api/orders',(req,res)=>{
  const {network,phone,planId,email}=req.body;
  const plan=db.prepare('SELECT * FROM data_plans WHERE id=? AND active=1').get(planId);
  if(!plan || !network || !/^0\d{10}$/.test(phone))
    return res.status(400).json({error:'Invalid order details'});
  const reference=ref();
  const info=db.prepare(`INSERT INTO orders(reference,network,phone,plan_id,amount_kobo,status)
    VALUES(?,?,?,?,?,'pending')`).run(reference,network,phone,plan.id,plan.selling_price_kobo);
  res.json({orderId:info.lastInsertRowid,reference,amountKobo:plan.selling_price_kobo,email:email||''});
});

app.post('/api/payment/initialize',async(req,res)=>{
  const {reference,email}=req.body;
  const order=db.prepare('SELECT * FROM orders WHERE reference=?').get(reference);
  if(!order) return res.status(404).json({error:'Order not found'});
  if(!process.env.PAYSTACK_SECRET_KEY) return res.status(503).json({error:'Paystack test key not configured'});
  try{
    const r=await fetch('https://api.paystack.co/transaction/initialize',{
      method:'POST',
      headers:{Authorization:'Bearer '+process.env.PAYSTACK_SECRET_KEY,'Content-Type':'application/json'},
      body:JSON.stringify({email,amount:order.amount_kobo,reference,metadata:{orderId:order.id}})
    });
    const data=await r.json();
    if(!r.ok||!data.status) return res.status(400).json({error:data.message||'Initialization failed'});
    res.json({authorization_url:data.data.authorization_url,reference});
  }catch(e){res.status(500).json({error:e.message});}
});

app.get('/api/payment/verify/:reference',async(req,res)=>{
  const reference=req.params.reference;
  const order=db.prepare('SELECT o.*,p.name plan_name FROM orders o JOIN data_plans p ON p.id=o.plan_id WHERE o.reference=?').get(reference);
  if(!order) return res.status(404).json({error:'Order not found'});
  if(!process.env.PAYSTACK_SECRET_KEY) return res.status(503).json({error:'Paystack test key not configured'});
  try{
    const r=await fetch('https://api.paystack.co/transaction/verify/'+encodeURIComponent(reference),{
      headers:{Authorization:'Bearer '+process.env.PAYSTACK_SECRET_KEY}
    });
    const data=await r.json();
    if(!r.ok||!data.status) return res.status(400).json({error:data.message||'Verification failed'});
    const tx=data.data;
    if(tx.status!=='success'||Number(tx.amount)!==Number(order.amount_kobo)){
      db.prepare("UPDATE orders SET status='failed',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(order.id);
      return res.status(400).json({error:'Payment not verified'});
    }
    db.prepare("UPDATE orders SET status='paid',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(order.id);
    db.prepare("INSERT OR IGNORE INTO payments(order_id,provider,provider_reference,amount_kobo,status,raw_response) VALUES(?,?,?,?,?,?)")
      .run(order.id,'paystack',reference,tx.amount,'success',JSON.stringify(tx));

    const vtu=await purchaseData({network:order.network,phone:order.phone,plan:order.plan_name,reference});
    db.prepare("UPDATE orders SET vtu_status=?,vtu_reference=?,updated_at=CURRENT_TIMESTAMP WHERE id=?")
      .run(vtu.status,vtu.providerReference||null,order.id);
    res.json({verified:true,order:{...order,status:'paid'},vtu});
  }catch(e){res.status(500).json({error:e.message});}
});

app.get('/api/admin/summary',admin,(req,res)=>{
  const orders=db.prepare('SELECT COUNT(*) n FROM orders').get().n;
  const revenue=db.prepare("SELECT COALESCE(SUM(amount_kobo),0) n FROM orders WHERE status='paid'").get().n;
  const pending=db.prepare("SELECT COUNT(*) n FROM orders WHERE status IN ('pending','paid') AND (vtu_status IS NULL OR vtu_status='pending')").get().n;
  res.json({orders,revenueKobo:revenue,pending});
});
app.get('/api/admin/orders',admin,(req,res)=>{
  res.json(db.prepare(`SELECT o.id,o.reference,o.network,o.phone,p.name plan_name,
    o.amount_kobo,o.status,o.vtu_status,o.vtu_reference,o.created_at
    FROM orders o JOIN data_plans p ON p.id=o.plan_id ORDER BY o.id DESC LIMIT 100`).all());
});

app.listen(PORT,()=>console.log('BSM Data Sub running on http://localhost:'+PORT));
