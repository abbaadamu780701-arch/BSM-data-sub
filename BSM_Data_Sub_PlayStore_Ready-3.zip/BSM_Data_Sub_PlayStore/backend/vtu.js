// Provider adapter. Keep provider secrets on the server only.
// Configure a legitimate VTU provider through environment variables.
// Do not hard-code credentials.

async function purchaseData({network,phone,plan,reference}) {
  if (!process.env.VTU_BASE_URL || !process.env.VTU_API_KEY) {
    return {configured:false,status:'not_configured',message:'VTU provider not configured'};
  }

  // Provider-specific request goes here after reviewing that provider's API contract.
  // Expected normalized result:
  // {configured:true,status:'success'|'pending'|'failed',providerReference:'...'}
  return {configured:true,status:'pending',message:'Provider adapter placeholder'};
}

module.exports={purchaseData};
