const Database=require('better-sqlite3');
const path=require('path');
const db=new Database(path.join(__dirname,'bsm-data-sub.sqlite'));
db.pragma('journal_mode = WAL');
const schema=require('fs').readFileSync(path.join(__dirname,'../database/schema.sql'),'utf8');
db.exec(schema);
module.exports=db;
