let plans=[];
const $=id=>document.getElementById(id);
function page(id){['home','buy','history','admin'].forEach(x=>$(x).hidden=x!==id)}
async function init(){
 const r=await fetch('/api/plans'); plans=await r.json();
 $('plan').innerHTML=plans.map(p=>`<option value="${p.id}" data-network="${p.network}">${p.network} — ${p.name} — ₦${(p.selling_price_kobo/100).toLocaleString()}</option>`).join('');
}
$('network').onchange=()=>{let n=$('network').value; $('plan').innerHTML=plans.filter(p=>p.network===n).map(p=>`<option value="${p.id}">${p.name} — ₦${(p.selling_price_kobo/100).toLocaleString()}</option>`).join('')}
async function startPayment(){
 const email=$('email').value.trim(), phone=$('phone').value.trim(), planId=Number($('plan').value), network=$('network').value;
 if(!email||!/^[0-9]{11}$/.test(phone)) return $('msg').textContent='Enter email and valid 11-digit phone.';
 let r=await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,phone,planId,network})});
 let o=await r.json(); if(!r.ok)return $('msg').textContent=o.error;
 r=await fetch('/api/payment/initialize',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reference:o.reference,email})});
 let p=await r.json(); if(!r.ok)return $('msg').textContent=p.error;
 localStorage.setItem('lastOrder',o.reference); location.href=p.authorization_url;
}
async function loadAdmin(){
 const token=$('adminToken').value;
 let s=await fetch('/api/admin/summary',{headers:{'x-admin-token':token}}), sum=await s.json();
 if(!s.ok)return $('adminOut').textContent=sum.error;
 let r=await fetch('/api/admin/orders',{headers:{'x-admin-token':token}}), orders=await r.json();
 $('adminOut').innerHTML=`<p>Orders: ${sum.orders} | Revenue: ₦${(sum.revenueKobo/100).toLocaleString()} | Pending VTU: ${sum.pending}</p>`+
 orders.map(o=>`<div class="order"><b>${o.reference}</b> — ${o.network} ${o.plan_name}<br>${o.phone} — ₦${(o.amount_kobo/100).toLocaleString()} — ${o.status} / ${o.vtu_status||'n/a'}</div>`).join('');
}
init();
