# BSM Data Sub Full MVP
A test-first Nigerian data/Vtu business application structure.

Includes:
- Mobile-friendly customer frontend
- Express backend
- SQLite-ready database schema
- Admin dashboard
- Paystack test payment flow
- VTU provider adapter structure
- Environment-variable secrets

Run backend:
1. Node.js 18+
2. `cd backend`
3. `npm install`
4. Copy `.env.example` to `.env`
5. Put TEST credentials only in `.env`
6. `npm start`
7. Open http://localhost:3000

This version does not deliver real data until a legitimate VTU provider is configured.
Never put secret keys in frontend code or chat.
