# BSM Data Sub — matakin ƙarshe

An shirya Android project da workflow na gina AAB.

- AAB ba a wallafa shi kai tsaye daga ZIP ba; Google Play Console ne ake amfani da shi.
- Google account/Play Console da verification dole su kasance na mai app.
- Real payment da real data delivery suna bukatar backend mai aiki da legitimate providers.
- Kada a saka Paystack secret key ko VTU secret a cikin Android app.

A GitHub: upload project -> Actions -> Build BSM Data Sub Android -> download AAB -> Play Console.
