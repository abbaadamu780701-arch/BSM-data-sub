# BSM Data Sub — Shirin Play Store

An gina Android wrapper project a `android/`.

Abubuwan da suka rage kafin a wallafa:
1. A yi build na AAB daga `android/`.
2. A saka app icon da screenshots na gaske.
3. A tabbatar da privacy policy da bayanan kamfani.
4. A bude/yi amfani da Google Play Console account.
5. A gwada app a Android na gaske.
6. A haɗa backend na BSM Data Sub da legitimate payment/VTU provider kafin real sales.

Muhimmi:
- Wannan Android wrapper yana kunshe da frontend; real payment/data delivery har yanzu yana bukatar backend mai aiki.
- Kada a saka Paystack secret key ko VTU secret a cikin Android app.
- Secret keys su kasance a backend kawai.
